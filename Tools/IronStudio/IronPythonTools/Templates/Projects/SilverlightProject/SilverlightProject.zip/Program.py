def SayHello(s,e):
    window.Alert("Hello, World!")
 
document.Button1.events.onclick += SayHello
