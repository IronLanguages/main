print 'Hello World'
