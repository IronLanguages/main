require 'rubygems'
require 'spec'

describe 'New specs' do
  it 'should fail' do
    true.should == false
  end
end