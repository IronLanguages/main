class Program
  def hello_world
    return 42
  end
end