document.say_hello.onclick do |s, e|
  window.alert("Hello, world!")
end
